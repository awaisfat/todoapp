import React, { useState } from "react";
import "../App.css"

import empIcon from "../assets/employee_icon.png"

export const AddTodo = ({ addTodo }) => {
  const [title, setTitle] = useState("");
  const submit = (e) => {
    console.log("running");
    e.preventDefault();
    if (!title) {
      alert("this is blank");
    }
    addTodo(title);
    setTitle(""); //this is for toblank the input After add some thing to the list
  };
  return (
    <div className="container my-3">
  
      <h3>Add</h3>
      <form onSubmit={submit}>
        <div className="mb-3">
          <label htmlFor="title" className="form-label">
            Write some thing
          </label>
         
          <div className="inputwithbutton">
          <img src={empIcon} alt="not found" className="empImage"/>
          <input
          placeholder="write something here"
            type="text"
            maxLength={20}
            value={title}
            
            onChange={(e) => {
              setTitle(e.target.value);
            }}
            
            className="form-control"
            id="title"
            />
          
           <button type="submit" className="btn btn-sm btn-white">
          Submit
        </button>
        
          </div>
        </div>
        
       
      </form>
      
    </div>
  );
};
