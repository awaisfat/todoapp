import React from "react";
import { TodoItem } from "./TodoItem";

export const Todos = (props) => {
  return (
  
    <div className="container">
    <hr />
      <h3 className="">Added items List</h3>
      <hr />
      {/* ////////////////////////////////////////////// */}
      {/* this is foe to delete the added things  we add for loop*/}
      {props.todos.map((todo) => {
        return <TodoItem todo={todo} onDelete={props.onDelete} />;
      })} 
     
    </div>

  );
};
