import React from 'react'
import "../App.css"

export const TodoItem = ({todo, onDelete}) => {
  return (
    <div className='cards'>
      <h4 className='holdData'>{todo?.title}
      </h4>
      <span>
        <button className='btn btn-sm btn-danger' onClick={ ()=>{onDelete(todo)}}>delete</button>
        
       </span>
      
    </div>
  )
}

