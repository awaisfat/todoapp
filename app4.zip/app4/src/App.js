import "./App.css";
import Header from "./mycomponent/Header";
import { Todos } from "./mycomponent/Todos";
import { AddTodo } from "./mycomponent/AddTodo";
import React, { useState, useEffect,  } from "react";

function App() {
  
  const [search, setSearch]=useState();
  let initTodo;
  if (localStorage.getItem("todos") === null) {
    initTodo = [];
  } else {
    initTodo = JSON.parse(localStorage.getItem("todos"));
  }
  const onDelete = (todo) => {
    console.log("i am onDelete", todo);
    // // deleteing this way is not working
    // let index= todos.indexOf(todo);
    // todos.splice(index, 1);
    setTodos(
      todos.filter((e) => {
        return e !== todo;
      })
    );
    localStorage.setItem("todos", JSON.stringify(todos));
  };
  const addTodo = (title) => {
    console.log("i am adding this todo", title);
    let sno;
    if (todos.length == 0) {
      sno = 0;
    } else {
      sno = todos[todos.length - 1].sno + 1;
    }

    const myTodo = {
      sno: sno,
      title: title,
    };
    setTodos([...todos, myTodo]);
    console.log("fun :",myTodo);
  };

  //objects

  const [todos, setTodos] = useState(initTodo);
  
  const filteredRecord=()=>{
   if(search){
    const getFilterRec=todos?.filter((item)=>item?.title===search);
    setTodos(getFilterRec);
   }
    
  }
  console.log("todo :", todos);
useEffect(()=>{
  filteredRecord();
},[search, setSearch])

 
  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos)) 
  }, [todos]); 
  
  return (
    <>
      <div className="main_container">
        <Header setSearch={setSearch}/>
        <AddTodo addTodo={addTodo} />
        <Todos todos={todos} onDelete={onDelete} />
      </div>
    </>
  );
 
}


export default App;
